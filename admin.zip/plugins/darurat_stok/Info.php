<?php

    return [
        'name'          =>  'Darurat Stok',
        'description'   =>  'Modul databarang untuk mLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '4.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
