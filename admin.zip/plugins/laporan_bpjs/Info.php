<?php

    return [
        'name'          =>  'Laporan BPJS',
        'description'   =>  'Modul mlite antrian referensi untuk mLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '4.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
