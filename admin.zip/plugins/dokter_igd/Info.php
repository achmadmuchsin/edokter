<?php

return [
    'name'          =>  'Dokter IGD',
    'description'   =>  'Modul dokter IGD untuk mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '4.*.*',
    'icon'          =>  'user-md',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
