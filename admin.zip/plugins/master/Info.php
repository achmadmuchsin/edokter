<?php

return [
    'name'          =>  'Master Data',
    'description'   =>  'Data master awal mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '4.*.*',
    'icon'          =>  'cubes',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
