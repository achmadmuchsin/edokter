<?php

return [
    'name'          =>  'Kepegawaian',
    'description'   =>  'Pengelolaan data kepegawaian mLITE.',
    'author'        =>  'Basoro',
    'version'       =>  '1.1',
    'compatibility' =>  '4.*.*',
    'icon'          =>  'group',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
