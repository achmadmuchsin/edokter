<?php

return [
    'name'          =>  'Inventaris',
    'description'   =>  'Modul inventaris, pemeliharana dan perbaikan untuk mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '4.*.*',
    'icon'          =>  'cog',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
