<?php

return [
    'name'          =>  'Kasir Rawat Inap',
    'description'   =>  'Modul kasir rawat inap untuk mLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '4.*.*',
    'icon'          =>  'money',
    'install'       =>  function () use ($core) {
    },
    'uninstall'     =>  function() use($core)
    {
    }
];
