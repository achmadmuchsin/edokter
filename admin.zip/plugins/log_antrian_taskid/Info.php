<?php

    return [
        'name'          =>  'Log Antrian TaskID',
        'description'   =>  'Modul mlite antrian referensi taskid untuk mLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '4.*.*',
        'icon'          =>  'code',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
