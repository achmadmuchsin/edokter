<?php

    return [
        'name'          =>  'Bridging HFIS',
        'description'   =>  'Modul Bridging HFIS di mLITE',
        'author'        =>  'Adly',
        'version'       =>  '1.0',
        'compatibility' =>  '4.*.*',
        'icon'          =>  'shield',
        'install'       =>  function () use ($core) {
        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
